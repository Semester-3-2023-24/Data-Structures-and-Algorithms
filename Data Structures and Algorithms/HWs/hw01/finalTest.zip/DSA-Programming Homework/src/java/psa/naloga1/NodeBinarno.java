package psa.naloga1;

public class NodeBinarno {

	public NodeBinarno left, right;

	private static int counter;
	private int key;

	public NodeBinarno(int el) {

		left = null;
		right = null;
		key = el;

	}

	public boolean push(NodeBinarno element) {

		int a = this.compare(element);
		if (a == 0)
			return false;
		else if (a < 0) {
			if (left == null) {
				left = element;
				return true;
			} else {
				return left.push(element);
			}
		}

		else {
			if (right == null) {
				right = element;
				return true;
			} else {
				return right.push(element);
			}
		}
	}

	public static boolean find(int element, NodeBinarno node) {

		boolean found = false;

		counter++; 
		
		while (!found && node != null) {

			if (element < node.key) {
				node = node.left;
			} else if (element > node.key) {
				node = node.right;
			} else {
				found= true;
				break;
			}

			found = find(element, node);
		}

		return found;
	}

	public static NodeBinarno remove(NodeBinarno root, int element) {

		if (root == null) {
			return root;
		}

		if (element < root.key)
			root.left = remove(root.left, element);
		else if (element > root.key)
			root.right = remove(root.right, element);

		else {
			if (root.left == null)
				return root.right;
			else if (root.right == null)
				return root.left;

			root.key = findMin(root.right);

			root.right = remove(root.right, root.key);
		}
		return root;
	}

	public static int findMin(NodeBinarno root) {
		int minimalValue = root.key;
		while (root.left != null) {
			minimalValue = root.left.key;
			root = root.left;
		}
		return minimalValue;
	}

	public int compare(NodeBinarno node) {
		counter++;
		return node.key - this.key;
	}

	public int getCounter() {
		return counter;
	}

	public void resetCounter() {
		counter = 0;
	}

}
