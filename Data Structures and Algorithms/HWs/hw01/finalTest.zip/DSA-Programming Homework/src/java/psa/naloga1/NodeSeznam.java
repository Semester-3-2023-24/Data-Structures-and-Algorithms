package psa.naloga1;

public class NodeSeznam {

	static int counter;
	public int key;
	
	public NodeSeznam next;

	public NodeSeznam(int element) {
		key = element;
		next = null;
	}

	public boolean push(NodeSeznam element) {
		if (this.compare(element) == 0) {
			return false;
		}

		if (next == null) {
			next = element;
			return true;
		}

		return next.push(element);
	}

	public int compare(NodeSeznam node) {
		counter++;
		return node.key - this.key;
	}

	public int getCounter() {
		return counter;
	}

	public void resetCounter() {
		counter = 0;
	}
}
