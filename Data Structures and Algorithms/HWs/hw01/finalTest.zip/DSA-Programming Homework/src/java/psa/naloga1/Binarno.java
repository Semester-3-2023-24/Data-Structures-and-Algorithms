package psa.naloga1;

public class Binarno {

	private NodeBinarno root;

	public boolean insert(int el) {

		if (root == null) {
			root = new NodeBinarno(el);
			return true;
		} else {
			return root.push(new NodeBinarno(el));
		}
	}

	public boolean delete(int el) {

		if (NodeBinarno.find(el, root)) {
			return NodeBinarno.remove(root, el) == null ? false : true;
		}

		return false; 
	}

	public boolean search(int el) {

		NodeBinarno node = root;

		return NodeBinarno.find(el, node);
	}

	public int getCounter() {
		return root != null ? root.getCounter() : null;
	}

	public void resetCounter() {
		if (root != null)
			root.resetCounter();
	}
}
