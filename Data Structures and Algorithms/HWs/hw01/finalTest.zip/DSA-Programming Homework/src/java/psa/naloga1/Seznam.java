package psa.naloga1;

public class Seznam {
	private NodeSeznam head;

	public boolean insert(int el) {
		if (head == null) {
			head = new NodeSeznam(el);
			return true;
		} else {
			return head.push(new NodeSeznam(el));
		}
	}
	
	public boolean delete(int el) {

		NodeSeznam temp = head, previous = null;

		if (temp != null && temp.key == el) {
			head = temp.next;
			return true;
		}

		while (temp != null && temp.key != el) {
			previous = temp;
			temp = temp.next;
		}

		if (temp == null)
			return false;

		previous.next = temp.next;
		return false;

	}

	public boolean search(int el) {

		if (head == null) {
			return false;
		}

		NodeSeznam node = head;
		boolean found = false;

		while (node != null) {
			
			NodeSeznam.counter ++;
			if (node.key == el) {
				found = true;
				break;
			}

			node = node.next;
		}

		return found;
	}

	public int getCounter() {
		return head != null ? head.getCounter() : null;
	}

	public void resetCounter() {
		if (head != null)
			head.resetCounter();
	}
}
