package psa.naloga1;

public class NodeSeznam {
	private static int counter;
	int key;
	NodeSeznam tail;
	//this is the constructor that will initialize a node with a key
	public NodeSeznam(int key, NodeSeznam tail){
		this.key = key;
		this.tail = tail;
	}

	public int getKey() {
		return key;
	}

	public int compare(NodeSeznam node) {
		counter++;
		return node.key - this.key;
	}
	public int getCounter() {
		return counter;
	}
	public void resetCounter() {
		counter=0;
	}
}