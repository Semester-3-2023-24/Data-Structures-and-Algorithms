package psa.naloga1;

public class NodeBinarno {
	private static int counter;
	private int key;
	//this is for the left child of the node
	NodeBinarno left;
	//this is for the right child of the nodee
	NodeBinarno right;
	//this is the constructor for the class "NodeBinarno"
	public NodeBinarno(int key, NodeBinarno right, NodeBinarno left){
		this.key = key;
		//with the next line I am assigning the left child of the node
		this.left = left;
		//with the next line I am assigning the left child of the node
		this.right = right;
	}
	public int compare(NodeBinarno node) {
		counter++;
		return node.key - this.key;
	}
	
	public int getCounter() {
		return counter;
	}
	
	public void resetCounter() {
		counter=0;
	}
}