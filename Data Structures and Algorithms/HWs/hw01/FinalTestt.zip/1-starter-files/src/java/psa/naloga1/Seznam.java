package psa.naloga1;

public class Seznam {
	private NodeSeznam head;
	public boolean insert(int element) {
		NodeSeznam SearchNode = new NodeSeznam(element, null);
		if (head == null)
		{
			head = SearchNode;
			return true;
		} else	{
			NodeSeznam NodeCurrent = head;
			while (NodeCurrent.tail != null){
				if (NodeCurrent.compare(SearchNode) == 0) {
					return false;
				}
				NodeCurrent = NodeCurrent.tail;
			}
			NodeCurrent.tail = SearchNode;
			return true;
		}
	}
	public boolean delete(int element) {
		NodeSeznam SearchNode = new NodeSeznam(element, null);
		if (head == null)
			return false;
		if (head.compare(SearchNode) == 0)
		{
			head = head.tail;
			return true;
		}
		NodeSeznam NodeCurrent = head;
		while (NodeCurrent.tail != null){
			if (NodeCurrent.tail.key == element){
				NodeCurrent.tail = NodeCurrent.tail.tail;
				return true;
			}
			NodeCurrent = NodeCurrent.tail;
		}
		return false;
	}
	public boolean search(int element) {
		NodeSeznam searchNode = new NodeSeznam(element, null);
		NodeSeznam node = head;
		while (node.tail != null){
			if (node.compare(searchNode) == 0)
				return true;
			node = node.tail;
		}
		if (node.compare(searchNode) == 0)
			return true;
		else
			return false;
	}
	public int getCounter() {
		return head != null?head.getCounter():null;
	}
	public void resetCounter() {
		if(head!= null)
			head.resetCounter();
	}
}