package psa.naloga1;

public class Binarno {
	private NodeBinarno root;
	private boolean delete;

	public boolean insert(int element) {
		NodeBinarno nodeInsert = new NodeBinarno(element, null, null);
		NodeBinarno CurrNode = insertRec(root, nodeInsert);
		if (CurrNode == null)
			return false;
		root = CurrNode;
		return true;
	}

	public NodeBinarno insertRec(NodeBinarno root, NodeBinarno elementsInNode) {
		if (root == null)
			return elementsInNode;
		int cmp = elementsInNode.compare(root);
		if (cmp < 0) {
			root.left = insertRec(root.left, elementsInNode);
		} else if (cmp > 0) {
			root.right = insertRec(root.right, elementsInNode);
		} else
			return null;
		return root;
	}

	public boolean delete(int element) {
		NodeBinarno DeleteNodeElement = new NodeBinarno(element, null, null);
		NodeBinarno ApplyDelNode = deleteRec(root, DeleteNodeElement);
		if (ApplyDelNode == null && delete == false) {
			return false;
		}
		root = ApplyDelNode;
		delete = false;
		return true;
	}

	public NodeBinarno deleteRec(NodeBinarno rootNode, NodeBinarno DeleteNodeElement) {
		if (rootNode == null) {
			return null;
		}
		int cmp = DeleteNodeElement.compare(rootNode);
		if (cmp < 0) {
			rootNode.left = deleteRec(rootNode.left, DeleteNodeElement);
		} else if (cmp > 0) {
			rootNode.right = deleteRec(rootNode.right, DeleteNodeElement);
		} else {
			delete = true;
			return null;
		}
		return rootNode;
	}

	public boolean search(int element) {
		NodeBinarno EleNodeSearch = new NodeBinarno (element, null, null);
		return searchRec(root, EleNodeSearch);
	}
	public boolean searchRec(NodeBinarno root, NodeBinarno EleNodeSearch){
		if (root == null)
			return false;
		int cmp = EleNodeSearch.compare(root);
		if (cmp < 0){
			return searchRec(root.left, EleNodeSearch);
		} else if (cmp > 0){
			return searchRec(root.right, EleNodeSearch);
		} else {
			return true;
		}
	}

	public int getCounter() {
		return root != null?root.getCounter():0;
	}

	public void resetCounter() {
		if(root!= null)
			root.resetCounter();
	}
}